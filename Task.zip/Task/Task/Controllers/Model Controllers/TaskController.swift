//
//  TaskController.swift
//  Task
//
//  Created by Ethan Andersen on 4/21/21.
//

import Foundation

class TaskController {
    static let sharedInstance = TaskController()
    
    var tasks: [Task] = []
    
    //MARK: - CRUD Functions
    
    func createTask(name: String, notes: String?, dueDate: Date?) {
        // Pass in variables from the Task model
        // Assign those variables to tasks (From the Task Controller), append, and save to persistence
        let newTask = Task(name: name, notes: notes, dueDate: dueDate)
        tasks.append(newTask)
        saveToPersistenceStore()
    }
    
    func updateTask(task: Task, name: String, notes: String?, dueDate: Date?) {
        // Pass in variables from Task model
        // Reasign the old name, notes, and dates
        // Save to persistence
        task.name = name
        task.notes = notes
        task.dueDate = dueDate
        saveToPersistenceStore()
    }
    
    func toggleIsComplete(task: Task) {
        task.isComplete.toggle()
        saveToPersistenceStore()
    }
    
    func deleteTask(task: Task) {
        // Pass in the needed variables from the Task model
        // Locate the task's index within the array
        // Remove them from the task using task.remove
        // Save to persistence
        guard let index = tasks.firstIndex(of: task) else {return}
        tasks.remove(at: index)
        saveToPersistenceStore()
    }
    
    
    //MARK: - Persistence
    func createPersistenceStore() -> URL {
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let fileURL = url[0].appendingPathComponent("Task.json")
        return fileURL
    }
    
    func saveToPersistenceStore() {
        do {
            let data = try JSONEncoder().encode(tasks)
            try data.write(to: createPersistenceStore())
        } catch {
            print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
        }
    }
    
    func loadFromPersistenceStore() {
        do {
            let data = try Data(contentsOf: createPersistenceStore())
            tasks = try JSONDecoder().decode([Task].self, from: data)
        } catch {
            print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
        }
    }
    
}
