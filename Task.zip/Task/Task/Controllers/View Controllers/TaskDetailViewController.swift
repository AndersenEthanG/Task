//
//  TaskDetailViewController.swift
//  Task
//
//  Created by Ethan Andersen on 4/21/21.
//

import UIKit

class TaskDetailViewController: UIViewController {

    //MARK: - Outlets
    
    @IBOutlet weak var taskNameTextField: UITextField!
    @IBOutlet weak var taskNotesTextView: UITextView!
    @IBOutlet weak var taskDueDatePicker: UIDatePicker!
    
    
    var task: Task?
    var date: Date?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
    }

    //MARK: - Actions
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        // Not sureu what this is really for, I guess it checks if the name field is empty or not. What that is for? That's the real question
        guard let name = taskNameTextField.text, !name.isEmpty else { return }
        // Declare a variable and assign it to the information that was entered by the user
        // Check if the taks already exists based on the attributes
        if let task = task {
            // Reference TaskController for existing information
            TaskController.sharedInstance.updateTask(task: task, name: name, notes: taskNotesTextView.text, dueDate: date)
        } else {
            TaskController.sharedInstance.createTask(name: name, notes: taskNotesTextView.text, dueDate: date)
        }
        // Pop the navigation controller
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func dueDatePickerDateChange(_ sender: Any) {
        // Sets the self date to the task date
        self.date = taskDueDatePicker.date
    }
    
    
    // When called, this will make sure the text and date and image fields are all proper based on the task variable passed in
    func updateViews() {
        guard let task = task else { return }
        // Set the text of the name field to the task.name
        taskNameTextField.text = task.name
        // Do the same for the notes and due date
        taskNotesTextView.text = task.notes
        taskDueDatePicker.date = task.dueDate ?? Date()
    }
    
}
