//
//  TaskListTableViewController.swift
//  Task
//
//  Created by Ethan Andersen on 4/21/21.
//

import UIKit

class TaskListTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TaskController.sharedInstance.loadFromPersistenceStore()
    }
    
    // Make sure the view loads
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the amount of rows there are in the array
        return TaskController.sharedInstance.tasks.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Set a guarded variable cell to the information of the dequeue Identified cell (Storyboard)
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "taskCell", for: indexPath) as? TaskTableViewCell else { return UITableViewCell() }
        
        // Set a variable task to be equal to the proper TaskController array, based on our row
        let task = TaskController.sharedInstance.tasks[indexPath.row]
        
        // Set the Cell delegate to itself
        cell.delegate = self
        
        // Set the cell task to task
        cell.task = task
        
        // Return the information that we just make
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.frame.height / 7
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        let taskToDelete = TaskController.sharedInstance.tasks[indexPath.row]
        // Pass in the information to Task Controller about the task to delete
        TaskController.sharedInstance.deleteTask(task: taskToDelete)
        // Delete the row
        tableView.deleteRows(at: [indexPath], with: .fade)
    }
    
    
    //MARK: - Navigation
    
    // Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // If statement, checking that our segue is the right one, IE the Identifier
        if segue.identifier == "toTaskDetailView" {
            // Guard declare the selected row index path
            guard let indexPath = tableView.indexPathForSelectedRow,
                  // Declare the destination
                  let destination = segue.destination as? TaskDetailViewController else { return }
            // Declare a task as the TaskControllers.sharedInstance's indexpath, where the data is from the row
            let task = TaskController.sharedInstance.tasks[indexPath.row]
            // Set the destination task to the defined task
            // Got an error, setup the detail view controller's landing pad
            destination.task = task
        }
    }
    
} //End of Class


//MARK: - Extensions

//Not too sure how these work yet, but this is what it should (?) look like
extension TaskListTableViewController: TaskCompletionDelegate {
    func taskCellButtonTapped(_ sender: TaskTableViewCell) {
        guard let task = sender.task else { return }
        TaskController.sharedInstance.toggleIsComplete(task: task)
        sender.updateView()
    }
} // End of Extension
