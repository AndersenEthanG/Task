//
//  TaskTableViewCell.swift
//  Task
//
//  Created by Ethan Andersen on 4/21/21.
//

import UIKit



protocol TaskCompletionDelegate: AnyObject {
    func taskCellButtonTapped(_ sender: TaskTableViewCell)
}

class TaskTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    @IBOutlet weak var taskNameLabel: UILabel!
    @IBOutlet weak var completionButton: UIButton!
    
    var task: Task? {
        didSet {
            updateView()
        }
    }

    //MARK: - Actions
    weak var delegate: TaskCompletionDelegate?
    
    @IBAction func completionButtonTapped(_ sender: Any) {
            delegate?.taskCellButtonTapped(self)
    }
    
    //MARK: - Functions
    
    func updateView() {
        guard let task = task else { return }
        // Set the text to the name of the task
        taskNameLabel.text = task.name
        // Check if the button is "complete", update the text to ""
        if task.isComplete {
            completionButton.setTitle("⬛️", for: .normal)
        } else {
            // Else if it is not complete update to 🔲
            completionButton.setTitle("🔲", for: .normal)
        }
        
    }
    
}
