//
//  Task.swift
//  Task
//
//  Created by Ethan Andersen on 4/21/21.
//

import Foundation

class Task: Codable {
    // Variables
    var name: String
    var notes: String?
    var dueDate: Date?
    var isComplete: Bool
    let uuid: String
    
    // Initializers
    init(name: String, notes: String?, dueDate: Date?, isComplete: Bool = false, uuid: String = UUID().uuidString) {
        self.name = name
        self.notes = notes
        self.dueDate = dueDate
        self.isComplete = isComplete
        self.uuid = uuid
    }
} // End of Class


//MARK: - Extensions
// Make an extension of the Task, with the type Equatable
// Make a static function that compairs the left hand side Task and the right hand side Task
// Return the name, notes and if it's complete, so that we can 
extension Task: Equatable {
    static func == (lhs: Task, rhs: Task) -> Bool {
        return lhs.uuid == rhs.uuid
    }
}
